def calcCost(count):
    if count <= 10:
        base_cost = count * 1
        discount = base_cost * 0.05
        price = base_cost - discount
        return price
    else:
        return base_cost
    
def displayline(lable, amount):
    print(f"{lable:>12}: {amount:>6.2f}") 

def Display(cost, tax):
    after_tax = cost + tax  
    displayline("Net cost: ", cost)
    displayline("Tax: ", tax)
    displayline("After tax: ", after_tax)
    return after_tax


