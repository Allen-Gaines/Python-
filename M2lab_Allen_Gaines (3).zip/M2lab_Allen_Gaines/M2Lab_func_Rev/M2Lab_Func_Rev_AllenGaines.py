# A brief description of the project
# Dat6/3/2025
# CSC121 m2Lab– Function Review
# Allen Gaines
import display_calculations

def main():
    while True:
        print('menue'+'--------------------')
        print("1) calculate cost")
        print ("2)  exit")
        print("--------------------------")
        
         # Get user input for choice
        choice = input("Enter your choice: ")   
        if choice == '1':  
            count = int(input("Enter the number of items: "))
            net_cost = display_calculations.calcCost(count)
            tax = net_cost * 0.075
            display_calculations.Display(net_cost, tax)

            
        
        elif choice == '2':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please try again.")
        
        

if __name__ == "__main__":
    main()

